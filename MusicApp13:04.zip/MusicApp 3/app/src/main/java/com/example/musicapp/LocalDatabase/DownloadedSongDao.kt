package com.example.musicapp.LocalDatabase

import androidx.room.Dao


@Dao
interface DownloadedSongDao {
//    @Insert
//    fun insert(song: DownloadedSong)
//
//    @Query("SELECT * FROM songs")
//    suspend fun getAllDownloadedSongs(): List<DownloadedSong>
}



