package com.example.musicapp

object MusicPlayerManager {
    var currentPlayingSongId: String? = null
}