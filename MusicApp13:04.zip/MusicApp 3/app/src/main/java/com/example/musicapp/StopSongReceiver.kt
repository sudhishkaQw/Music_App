package com.example.musicapp

import android.content.BroadcastReceiver
import android.content.Context

//class StopSongReceiver : BroadcastReceiver() {
//    override fun onReceive(context: Context?, intent: Intent?) {
//        // Stop the song if it's playing
//        if (customPlayer.isPlaying()) {
//            customPlayer.pause()
//        }
//    }
//}